﻿namespace System.Drawing
{
    internal class Color
    {
    }
}